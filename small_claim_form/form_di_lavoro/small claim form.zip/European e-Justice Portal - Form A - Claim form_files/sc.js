function gotoSCC()
{
	if (confirm(alertMessageGotoC))
	{
		isMyUnload = true;
		document.location = "dynform_sc_a_2_c_action.do";
	}
}

